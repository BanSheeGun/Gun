#include<stdio.h>
int main(void){
    int n;
    scanf("%d",&n);
    if ((n%400==0)||(n%4==0&&n%100!=0)) printf("366");
    	else printf("365");
    return 0;
}